import React from "react";
import Waste2Wealth from "./components/Waste2Wealth";

function App() {
  return <Waste2Wealth />;
}

export default App;
