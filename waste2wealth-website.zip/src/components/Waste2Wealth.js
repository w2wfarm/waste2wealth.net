import React from "react";

export default function Waste2Wealth() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="bg-green-700 text-white p-6">
        <h1 className="text-4xl font-bold">Waste 2 Wealth (W2W)</h1>
        <p className="text-lg">Be the Change</p>
      </header>
      <main className="p-6 grid gap-8">
        <section>
          <h2 className="text-2xl font-semibold mb-2">About Waste 2 Wealth</h2>
          <p>
            Waste2Wealth is a sustainable farming and cryptocurrency project. We convert organic waste using Black Soldier Flies (BSF) and distribute valuable protein for livestock. Our W2W Token lets investors contribute to our cause and earn from our growth.
          </p>
        </section>
        <section>
          <h2 className="text-2xl font-semibold mb-2">W2W Meme Coin</h2>
          <p>
            The W2W Token is a meme coin supporting our eco-farm. Investors gain profits from token appreciation and farm revenues.
          </p>
          <h3 className="text-xl font-semibold mt-4">Token Contract Address</h3>
          <p className="break-all">GerQRzDQDFX8GeS1By1MH5Dr3ykiyMma7To488FRpump</p>
          <a href="https://pump.fun" target="_blank" rel="noopener noreferrer"
             className="inline-block mt-4 px-6 py-2 bg-purple-600 text-white rounded-full hover:bg-purple-700">
            Buy W2W on Pump.fun
          </a>
        </section>
        <section>
          <h2 className="text-2xl font-semibold mb-2">Tokenomics</h2>
          <ul className="list-disc list-inside">
            <li>Total Supply: 1,000,000,000 W2W Tokens</li>
            <li>50% Public Sale</li>
            <li>20% Development Fund</li>
            <li>15% Team & Advisors</li>
            <li>10% Marketing & Partnerships</li>
            <li>5% Reserve Fund</li>
          </ul>
        </section>
        <section>
          <h2 className="text-2xl font-semibold mb-2">Contact Us</h2>
          <form action="https://formsubmit.co/YOUR_EMAIL@example.com" method="POST" className="grid gap-4">
            <input type="text" name="name" placeholder="Your Name" required className="border p-2 rounded" />
            <input type="email" name="email" placeholder="Your Email" required className="border p-2 rounded" />
            <textarea name="message" rows="5" placeholder="Your Message" required className="border p-2 rounded"></textarea>
            <button type="submit" className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Send Message</button>
          </form>
        </section>
        <section>
          <h2 className="text-2xl font-semibold mb-2">Blog</h2>
          <p>Coming soon: Updates on BSF farming, eco-initiatives, and W2W token news.</p>
        </section>
      </main>
      <footer className="bg-gray-100 text-center p-4 text-sm text-gray-500">
        &copy; 2025 Waste 2 Wealth. All rights reserved.
      </footer>
    </div>
  );
}
